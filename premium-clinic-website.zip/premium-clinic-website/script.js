const WHATSAPP_NUMBER = "91XXXXXXXXXX"; // Replace with clinic WhatsApp number, country code + number, digits only.
const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();

const dateInput = document.getElementById("appointmentDate");
const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split("T")[0];
dateInput.min = localToday;

const form = document.getElementById("appointmentForm");
const status = document.getElementById("formStatus");
form.addEventListener("submit", event => {
  event.preventDefault();
  status.textContent = "";
  status.classList.remove("error");
  if (!form.reportValidity()) return;

  const data = new FormData(form);
  const date = String(data.get("date"));
  if (date < localToday) {
    status.textContent = "Please select today or a future date.";
    status.classList.add("error");
    dateInput.focus();
    return;
  }
  if (!/^[0-9+() -]{8,18}$/.test(String(data.get("phone")).trim())) {
    status.textContent = "Please enter a valid contact number.";
    status.classList.add("error");
    return;
  }
  if (!/^\d{10,15}$/.test(WHATSAPP_NUMBER)) {
    status.textContent = "The clinic WhatsApp number has not been configured. Please contact the clinic by phone.";
    status.classList.add("error");
    return;
  }

  const lines = [
    "Hello, I would like to enquire about an appointment.",
    "",
    `Name: ${data.get("name")}`,
    `Mobile: ${data.get("phone")}`,
    `Email: ${data.get("email") || "Not provided"}`,
    `Doctor: ${data.get("doctor") || "Any available doctor"}`,
    `Department / service: ${data.get("department") || "Not selected"}`,
    `Preferred date: ${date}`,
    `Preferred time: ${data.get("time")}`,
    `Reason: ${data.get("reason") || "Not provided"}`,
    "",
    "Please confirm whether this date and time are available. I understand this is only an enquiry, not a confirmed booking."
  ];
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join("\\n"))}`;
  status.textContent = "Opening WhatsApp. Your appointment is not confirmed until the clinic replies.";
  window.open(url, "_blank", "noopener,noreferrer");
});

const lightbox = document.getElementById("lightbox");
const lightboxImage = lightbox.querySelector("img");
document.querySelectorAll(".gallery-item").forEach(item => item.addEventListener("click", () => {
  lightboxImage.src = item.dataset.full;
  lightboxImage.alt = item.querySelector("img").alt;
  lightbox.hidden = false;
  document.body.style.overflow = "hidden";
  lightbox.querySelector("button").focus();
}));
function closeLightbox() {
  lightbox.hidden = true;
  lightboxImage.src = "";
  document.body.style.overflow = "";
}
lightbox.querySelector("button").addEventListener("click", closeLightbox);
lightbox.addEventListener("click", event => { if (event.target === lightbox) closeLightbox(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !lightbox.hidden) closeLightbox(); });

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, {threshold:  0.12});
document.querySelectorAll(".section-head, .service-card, .why-grid>div, .blog-grid article, .review-placeholder").forEach(el => {
  el.classList.add("reveal");
  revealObserver.observe(el);
});

// Simple bilingual toggle for key navigation and CTA labels. Expand data translations as needed.
const translations = {
  en: {nav:["Home","About","Services","Doctors","Gallery","Contact"],book:"Book Appointment",hero:"Your Health,"},
  hi: {nav:["होम","हमारे बारे में","सेवाएँ","डॉक्टर","गैलरी","संपर्क"],book:"अपॉइंटमेंट लें",hero:"आपका स्वास्थ्य,"}
};
let language = "en";
document.getElementById("langToggle").addEventListener("click", () => {
  language = language === "en" ? "hi" : "en";
  const labels = translations[language];
  const links = nav.querySelectorAll('a[href^="#"]:not(.btn)');
  links.forEach((link, i) => { if (labels.nav[i]) link.textContent = labels.nav[i]; });
  const bookLink = nav.querySelector(".btn");
  bookLink.firstChild.textContent = labels.book + " ";
  document.getElementById("langToggle").textContent = language === "en" ? "हिन्दी" : "English";
  document.documentElement.lang = language === "hi" ? "hi" : "en";
  // This lightweight demo translates navigation/CTA only; translate all page copy before advertising full bilingual support.
});
