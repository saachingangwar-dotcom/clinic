# Premium Clinic Website Starter

A responsive, vanilla HTML/CSS/JavaScript clinic website starter. It is a **front-end enquiry website**, not a production patient-management or booking platform.

## Files
- `index.html` — all page sections, metadata and placeholder MedicalClinic structured data
- `styles.css` — responsive design and interactions styling
- `script.js` — mobile navigation, date validation, WhatsApp enquiry, gallery lightbox and small bilingual navigation toggle
- `404.html` — custom not-found page
- `privacy.html` / `terms.html` — editable policy templates (must be reviewed for your jurisdiction and actual data practices)
- `robots.txt` / `sitemap.xml` — starter SEO files; update the domain before deployment

## Before publishing — mandatory replacements
Search the project for square-bracket placeholders and `XXXXXXXXXX`. Replace:
1. Clinic name, city, state, full postal address and PIN.
2. Clinic phone and WhatsApp numbers. In `script.js`, set `WHATSAPP_NUMBER` to digits only including country code, e.g. `91` + ten-digit number.
3. Doctor's actual name, verified qualifications, specialization, experience and registration details (only if supplied/verified).
4. Opening hours, actual service list, facilities, insurance/payment details and clinic-specific policies.
5. Google Maps iframe URL and directions link with the exact clinic location.
6. Replace stock photos with clinic-owned or properly licensed images. Current images are illustrative Unsplash URLs.
7. Replace the generic domain in `sitemap.xml` and add a real canonical URL / social image when deployed.

Do not publish invented credentials, patient reviews, medical outcomes, clinic facilities, emergency availability or insurance claims. The review area intentionally contains no fabricated testimonials.

## Run locally
Open `index.html` in a browser, or use VS Code Live Server. No build step or package installation is required.

## Deploy on GitHub Pages
1. Create a GitHub repository (for example `clinic-website`).
2. Upload all files in this folder to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for the published URL and test it on phone and desktop.

## Appointment enquiry limitations
The form validates required fields and creates a pre-filled WhatsApp message. It does **not** save submissions, send email, reserve a slot, or confirm appointments. A clinic employee must verify availability and reply. For real online booking, add a secure backend, database, authentication, server-side validation, rate limiting, privacy controls, retention rules, backups and access logs. Avoid collecting sensitive medical information through an unsecured static form or personal WhatsApp account.

## Accessibility / SEO checks
- Check keyboard navigation, contrast, form labels and mobile layout.
- Add real clinic canonical URL, sitemap domain and verified structured data.
- Verify all links, phone numbers, map pins and opening hours.
- Get appropriate consent before publishing patient photos, names or testimonials.
- Have the clinic owner and a qualified privacy/legal professional review policy pages.
